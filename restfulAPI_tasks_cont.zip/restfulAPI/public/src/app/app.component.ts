import { Component, OnInit } from '@angular/core';
import { HttpService } from "./http.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  
  // ATTRIBUTE GOES HERE
  title = 'Restful Tasks API';  // TITLE ATTRI.  EMBEDDED ON THE INDEX.HTML PAGE (IT'S A COMPONENT OF THE APP)
  tasks: {};
  num: number;  // every attribute there needs to be a corresponding ngOnInit
  randNum: number;  // extra
  str: string;  // extra
  first_name: string;  // extra
  snacks: string[];  // extra
  loggedIn: boolean; // extra

  constructor(private _httpService: HttpService){}

  ngOnInit(){
      this.num = 7;   // extra
      this.randNum = Math.floor( (Math.random()  * 2 ) + 1);  // extra
      this.str = 'Hello Angular Developer!';  // extra
      this.first_name = 'Alpha';  // extra
      this.snacks = ["vanilla latte with skim milk", "garbage"];
      this.loggedIn = true;
      this.getTasksFromService();
  }
  
  // WHY IS THIS GET TASK METHOD INSIDE THE APP COMPONENT?
  getTasksFromService(){
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
    //    console.log("APPCOMPONENT!", Object.keys(data).length)
       console.log(data)
       this.tasks = data; /// pickup here
       console.log(this.tasks);
    });
 }

}

/// OLD CODE TO RETRIEVE TASKS.  NOTICE HERE IT IS OUTSIDE OF THE APPCOMPONENT
// getTasksFromService(){
//     let observable = this._httpService.getTasks();
//     console.log("***** app.component.ts getTask method running")
//     observable.subscribe(data => console.log("Got our tasks!", data));
// }
/////////////////////////////////////////////
